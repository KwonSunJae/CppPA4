#pragma once
class Character
{
};

